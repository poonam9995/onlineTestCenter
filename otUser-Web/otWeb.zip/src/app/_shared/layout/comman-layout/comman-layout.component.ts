import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comman-layout',
  templateUrl: './comman-layout.component.html',
  styleUrls: ['./comman-layout.component.scss']
})
export class CommanLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
